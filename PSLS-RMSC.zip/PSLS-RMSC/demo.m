addpath(genpath('gspbox-0.7.0/'));
addpath('datasets/');
addpath('fun/');

load("BBC.mat");
X = data';
gt = double(truelabel{1}');
class_num = length(unique(gt));

lambda1 = 0.1;
lambda2 = 1;
lambda3 = 0.1;
lambda4 = 10;
lambda5 = 0.001;

test_num = 10;
ACC_all = zeros(test_num, 1);

for i = 1:test_num
    S = test(X, lambda1, lambda2, lambda3, lambda4, lambda5);
    XX = Ng_SpectralClustering(S, class_num);

    [ACC, NMI, PUR] = ClusteringMeasure(gt, XX);
    [Fscore, Precision, Recall] = compute_f(gt, XX);
    [AR, ~, ~, ~] = RandIndex(gt, XX);

    ACC_all(i) = ACC;
end

fprintf('ACC 平均值 = %.4f，标准差 = %.4f\n', mean(ACC_all), std(ACC_all));
