function [S, history] = test(X, lambda1, lambda2, lambda3, lambda4, lambda5)
N = size(X{1}, 2);
V = length(X);
epson = 1e-5;
max_iter = 100;
I = eye(N);
mu = 0.1;
mu_max = 1e10;
rho = 2;

param2.verbose = 0;
param2.max_iter = 10;

for v = 1:V
    A{v} = constructW_PKN(X{v}, 5);
    D{v} = diag(sum(A{v}));
    L{v} = D{v} - A{v};
end

for v = 1:V
    Z{v} = zeros(N, N);
    E{v} = zeros(size(X{v}, 1), N);
    J{v} = zeros(N, N);
    Q{v} = zeros(N, N);
    P{v} = zeros(N, N);
    Y1{v} = zeros(size(X{v}, 1), N);
    Y2{v} = zeros(N, N);
    Y3{v} = zeros(N, N);
    Y4{v} = zeros(N, N);
end

history.obj = zeros(max_iter, 1);
history.diff = zeros(max_iter, 1);

for iter = 1:max_iter
    for v = 1:V
        Xv = X{v};
        A_mat = Xv' * Xv + lambda4 * L{v} + 3 * mu * I;
        B_mat = Xv' * (Xv - E{v} + Y1{v}/mu) + mu*(J{v} + Q{v} + P{v}) - (Y2{v} + Y3{v} + Y4{v});
        [L_mat, R_mat] = lu(A_mat);
        Z_vec = R_mat \ (L_mat \ B_mat);
        Z{v} = max(Z_vec, 0);
    end

    for v = 1:V
        F = X{v} - X{v} * Z{v} + Y1{v}/mu;
        E{v} = solve_l1l2(F, lambda3/mu);
    end

    for v = 1:V
        Temp = Z{v} + Y2{v}/mu;
        [U, S_mat, Vv] = svd(Temp, 'econ');
        sigma = diag(S_mat);
        tau = lambda1/mu;
        sigma_thresh = max(sigma - tau, 0);
        svp = sum(sigma_thresh > 0);
        if svp >= 1
            J{v} = U(:, 1:svp) * diag(sigma_thresh(1:svp)) * Vv(:, 1:svp)';
        else
            J{v} = zeros(size(Temp));
        end
    end

    for v = 1:V
        Q{v} = prox_TV(Z{v} + Y3{v}/mu, lambda2/mu, param2);
    end

    for v = 1:V
        Temp = Z{v} + Y4{v}/mu;
        lambda5_mu = lambda5/mu;
        a = max(P{v}, 1e-10);
        b = Temp;
        c = b - lambda5_mu * (log(a) + 1);
        p = max(b, 1e-6);
        for it = 1:10
            fp = lambda5_mu * log(p) + p - c;
            fdp = lambda5_mu ./ p + 1;
            p_new = p - fp ./ fdp;
            p_new = max(p_new, 1e-10);
            if norm(p_new - p, 'fro') < 1e-8
                break;
            end
            p = p_new;
        end
        P{v} = p;
    end

    obj = 0;
    for v = 1:V
        obj = obj + norm(E{v}, 'fro')^2;
        obj = obj + lambda4 * trace(Z{v}' * L{v} * Z{v});
        obj = obj + lambda1 * norm(J{v}, 'fro');
        obj = obj + lambda2 * tv_norm(Q{v});
        obj = obj + lambda5 * sum(sum(log(P{v})));
    end
    history.obj(iter) = obj;

    for v = 1:V
        Y1{v} = Y1{v} + mu * (X{v} - X{v}*Z{v} - E{v});
        Y2{v} = Y2{v} + mu * (Z{v} - J{v});
        Y3{v} = Y3{v} + mu * (Z{v} - Q{v});
        Y4{v} = Y4{v} + mu * (Z{v} - P{v});
    end

    max_diff = 0;
    for v = 1:V
        diffZ = norm(Z{v} - J{v}, 'fro') / max(1, norm(Z{v}, 'fro'));
        diffQ = norm(Z{v} - Q{v}, 'fro') / max(1, norm(Z{v}, 'fro'));
        diffP = norm(Z{v} - P{v}, 'fro') / max(1, norm(Z{v}, 'fro'));
        diffE = norm(X{v} - X{v}*Z{v} - E{v}, 'fro') / max(1, norm(X{v}, 'fro'));
        max_diff = max([max_diff, diffZ, diffQ, diffP, diffE]);
    end
    history.diff(iter) = max_diff;

    if max_diff < epson
        fprintf('Converged at iter %d\n', iter);
        history.obj(iter+1:end) = [];
        history.diff(iter+1:end) = [];
        break;
    end

    mu = min(mu * rho, mu_max);
end

S = zeros(N, N);
for v = 1:V
    S = S + (Z{v} + Z{v}') / 2;
end
S = S / V;
S = (S + S') / 2;  
end


function val = tv_norm(X)
[m, n] = size(X);
val = 0;
if n > 1
    val = val + sum(sum(abs(X(:, 2:end) - X(:, 1:end-1))));
end
if m > 1
    val = val + sum(sum(abs(X(2:end, :) - X(1:end-1, :))));
end
end